TOHEŞAR OBJECT LAB / 01 SHADOW UNIFORM / PHYSICAL SAMPLE 1-UNIT INTAKE
2026-11-09 · PREPRODUCTION · ARTWORK / PRODUCT / PRICE NOT APPROVED
This package is for OWNER REVIEW FIRST. No supplier file transmission authorized.

[INTENDED PRODUCT / verify store selection first]
Manufacturer: BECANVAS (비캔버스)
Blank: 32수 2합 피그먼트 반팔티 275gsm / cotton 100% / oversized
Desired garment color: 차콜 (charcoal), a real manufacturer-listed color.
Actual selectable vendor color and in-stock size: NOT VERIFIED
Quantity: 1 piece
Size: UNDECIDED, do not assume user's size
Product manufacturer evidence: https://becanvas.co.kr/shop_view/254
Potential 1-piece printer / options:
https://sendicode.com/product/becanvas-%EB%B9%84%EC%BA%94%EB%B2%84%EC%8A%A4-%ED%94%BC%EA%B7%B8%EB%A8%BC%ED%8A%B8-32%EC%88%98-2%ED%95%A9-275gsm-%EB%B0%98%ED%8C%94/16416/
Seller's published page shows 15,000 KRW *base item price*, a <=10cm print
option, color/size selectors, 5 file uploads <=5MB each, minimum 1 unit.
Seller's published delivery policy: 3,500 KRW below 200,000 KRW.
NO VERIFIED SELECTED-OPTIONS CHECKOUT OR VAT CONFIRMATION.

[PRINT ASSET]
01_LOGO_82mm_IVORY_TRANSPARENT_600DPI.png
- SOURCE-LOCKED original TOHEŞAR vector; NO generated text, no redrawn Ş.
- Print exactly 82.0 mm wide (18.854824 mm high, proportional).
- Transparent background: DO NOT print any black rectangle.
- Ivory warm ink reference #F8F2E7, not pure white.
- Put once on the upper front chest; exact offset from neckline /
  shoulder / center must be measured/approved in vendor proof.
- Vendor category to check: '소형인쇄(10cm이하)' (82 mm <= 100 mm).
  Category suitability does NOT guarantee acceptance.
- Ask supplier to identify DTF vs DTG/other method, textile white
  underbase, actual ivory color matching and wash durability.
- For source geometry, 02_LOGO_82mm_SOURCE_VECTOR.svg has exact same d path.

[PLACEMENT REFERENCE]
03_FRONT_CONCEPT_REFERENCE_NOT_MEASURED.png
- Existing R02 illustration; not photograph of actual blank.
- NOT true-to-life garment dimensions or approved print placement.
- Compare style and relative restraint only.

[CHECK BEFORE ORDER — all remain PENDING]
1. Confirm seller's actual CHARCOAL + chosen size selector and available stock.
2. Confirm garment's size table, measured shoulder/chest/body length.
3. Upload original 600 DPI PNG to vendor editor, inspect exact 82mm proof.
4. Verify print method/ink/placement, extra print surcharge, VAT.
5. Read one-unit final price including 3,500 KRW shipping or updated amount.
6. Obtain the owner's approval BEFORE submitting any files to vendor,
   contacting supplier, ordering, entering PII or making any payment.
7. Only after delivery: check printing edge/ivory tone/82mm size,
   true fit, inside label, wash test, front and back sample photos.

[STATUS]
Logo source checksum tested: YES
PNG generated and round-trip validated in prior CI: YES
Vendor editor import: NO
Vendor checkout total: NO
Manufacture ordered/received/worn/washed/photographed: NO
Owner-approved garment brand master: NOT ESTABLISHED
