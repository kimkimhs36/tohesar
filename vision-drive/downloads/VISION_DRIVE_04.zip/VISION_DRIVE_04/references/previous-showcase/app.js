/* Public demonstration only. This file has no transport or hardware adapter. */
(function (root) {
  'use strict';
  const directions = new Set(['forward', 'backward', 'left', 'right']);
  const powerValues = [85, 170, 255];
  function createSimulation() {
    return { direction: 'stop', power: 85, led: false, x: 0, y: 0, angle: 0 };
  }
  function advance(state, seconds, width, height) {
    const dt = Math.min(Math.max(seconds, 0), 0.05);
    const speed = 30 + state.power / 255 * 65;
    if (state.direction === 'left') state.angle -= 105 * dt;
    if (state.direction === 'right') state.angle += 105 * dt;
    if (state.direction === 'forward' || state.direction === 'backward') {
      const sign = state.direction === 'forward' ? 1 : -1;
      const radians = state.angle * Math.PI / 180;
      state.x += Math.sin(radians) * speed * dt * sign;
      state.y -= Math.cos(radians) * speed * dt * sign;
    }
    state.x = Math.max(-width, Math.min(width, state.x));
    state.y = Math.max(-height, Math.min(height, state.y));
    return state;
  }
  const api = { createSimulation, advance, directions, powerValues };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof document === 'undefined') return;

  const robot = document.querySelector('#demo-robot');
  if (!robot) return;
  const stage = robot.parentElement;
  const section = robot.closest('section') || document;
  const status = document.querySelector('#demo-direction');
  const powerLabel = document.querySelector('#demo-power');
  const ledStatus = document.querySelector('#demo-led-status');
  const led = document.querySelector('#demo-led');
  const driveButtons = [...document.querySelectorAll('[data-drive]')];
  const powerButtons = [...document.querySelectorAll('[data-power]')];
  const reset = document.querySelector('#demo-reset');
  const state = createSimulation();
  let active = null;
  let keyboardEnabled = false;
  let lastFrame = 0;
  let frame = 0;
  const labels = { forward: 'FORWARD', backward: 'REVERSE', left: 'LEFT', right: 'RIGHT', stop: 'STANDBY' };
  function render() {
    robot.style.transform = `translate(${state.x}px, ${state.y}px) rotate(${state.angle}deg)`;
    if (status) status.textContent = labels[state.direction];
    if (powerLabel) powerLabel.textContent = String(state.power);
    if (ledStatus) ledStatus.textContent = state.led ? 'ON' : 'OFF';
    if (led) led.setAttribute('aria-pressed', String(state.led));
    robot.classList.toggle('is-lit', state.led);
    driveButtons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.drive === state.direction && state.direction !== 'stop')));
    powerButtons.forEach(button => button.setAttribute('aria-pressed', String(Number(button.dataset.power) === state.power)));
  }
  function tick(time) {
    if (!lastFrame) lastFrame = time;
    const bounds = stage.getBoundingClientRect();
    advance(state, (time - lastFrame) / 1000, Math.max(0, bounds.width / 2 - 35), Math.max(0, bounds.height / 2 - 35));
    lastFrame = time;
    render();
    if (state.direction !== 'stop') frame = requestAnimationFrame(tick);
    else { frame = 0; lastFrame = 0; }
  }
  function stop() {
    active = null;
    state.direction = 'stop';
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
    lastFrame = 0;
    render();
  }
  function start(direction, owner) {
    if (!directions.has(direction)) return;
    // One input owns the simulation at a time; a second input cannot override it.
    if (active && active !== owner) return;
    active = owner;
    state.direction = direction;
    render();
    if (!frame) frame = requestAnimationFrame(tick);
  }
  section.addEventListener('pointerdown', () => { keyboardEnabled = true; });
  section.addEventListener('focusin', () => { keyboardEnabled = true; });
  document.addEventListener('pointerdown', event => {
    if (!section.contains(event.target)) { keyboardEnabled = false; stop(); }
  });
  document.addEventListener('focusin', event => {
    if (!section.contains(event.target)) { keyboardEnabled = false; stop(); }
  });
  driveButtons.forEach(button => {
    const direction = button.dataset.drive;
    if (direction === 'stop') {
      button.addEventListener('click', stop);
      button.addEventListener('pointerdown', event => { event.preventDefault(); stop(); });
      return;
    }
    button.addEventListener('pointerdown', event => {
      if (event.button !== 0 && event.pointerType === 'mouse') return;
      event.preventDefault();
      const owner = `pointer:${event.pointerId}`;
      try { button.setPointerCapture(event.pointerId); } catch (_) { /* capture may be unavailable */ }
      start(direction, owner);
    });
    const release = event => { if (active === `pointer:${event.pointerId}`) stop(); };
    button.addEventListener('pointerup', release);
    button.addEventListener('pointercancel', release);
    button.addEventListener('lostpointercapture', release);
    // Keyboard activation of a focused button remains a momentary input.
    button.addEventListener('keydown', event => {
      if ((event.key === 'Enter' || event.key === ' ') && !event.repeat) {
        event.preventDefault(); start(direction, `button:${event.key}`);
      }
    });
    button.addEventListener('keyup', event => {
      if (active === `button:${event.key}`) { event.preventDefault(); stop(); }
    });
  });
  // Catch releases even if pointer capture is unavailable.
  window.addEventListener('pointerup', event => { if (active === `pointer:${event.pointerId}`) stop(); });
  window.addEventListener('pointercancel', event => { if (active === `pointer:${event.pointerId}`) stop(); });
  powerButtons.forEach(button => button.addEventListener('click', () => {
    const value = Number(button.dataset.power);
    if (powerValues.includes(value)) { state.power = value; render(); }
  }));
  if (led) led.addEventListener('click', () => { state.led = !state.led; render(); });
  if (reset) reset.addEventListener('click', () => { stop(); Object.assign(state, createSimulation()); render(); });
  const keys = { w: 'forward', arrowup: 'forward', s: 'backward', arrowdown: 'backward', a: 'left', arrowleft: 'left', d: 'right', arrowright: 'right' };
  document.addEventListener('keydown', event => {
    const key = event.key.toLowerCase();
    if (key === 'escape' || (key === ' ' && keyboardEnabled && !/^(BUTTON|INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName))) { if (key === ' ') event.preventDefault(); stop(); return; }
    if (!keyboardEnabled || event.repeat || event.ctrlKey || event.altKey || event.metaKey || /^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName) || event.target.isContentEditable) return;
    if (keys[key]) { event.preventDefault(); start(keys[key], `key:${key}`); }
  });
  document.addEventListener('keyup', event => {
    const key = event.key.toLowerCase();
    if (active === `key:${key}`) { event.preventDefault(); stop(); }
  });
  window.addEventListener('blur', stop);
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });
  const menu = document.querySelector('#menu-toggle');
  const nav = document.querySelector('#site-nav');
  if (menu && nav) {
    menu.addEventListener('click', () => {
      const open = menu.getAttribute('aria-expanded') !== 'true';
      menu.setAttribute('aria-expanded', String(open));
      nav.classList.toggle('is-open', open);
    });
    nav.addEventListener('click', event => {
      if (event.target.closest('a')) { menu.setAttribute('aria-expanded', 'false'); nav.classList.remove('is-open'); }
    });
  }
  render();
})(typeof window !== 'undefined' ? window : globalThis);
